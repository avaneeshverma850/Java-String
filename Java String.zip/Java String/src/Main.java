
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
    //String name=new String("Avaneesh Verma");
        String Name="Avaneesh Verma";
        System.out.print("The name is:");
    System.out.println(Name);
    int a=6;
    float b=5.645f;
    //System.out.printf("the value of a is %d and value of b is %f",a,b);
       // System.out.format("the value of a is %d and value of b is %f",a,b);
        Scanner Sc=new Scanner(System.in);
        System.out.println("Enter String:");
        String st=Sc.nextLine();
        System.out.println(st);
    }
}